import React, { Component } from 'react';
import { Link } from 'react-router';
import { firebaseApp } from '../firebase';

class SignUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      error: {
        message: ''
      }
    }
  }

  signUp() {
    console.log('this.state', this.state);
    const { email, password } = this.state;
    firebaseApp.auth().createUserWithEmailAndPassword(email, password)
      .catch(error => {
        this.setState({error});
      })
  }

  render() {
    return (
<aside className="form1">
 <div className="dark">
  <h3>Registration</h3>
  <form className="logform quote" method="post">
    <input className="form-control" type="text" placeholder="Email..."
     onChange={event => this.setState({email: event.target.value})}
      required="required"/>
    <input className="form-control" type="password" placeholder="Password..."
     onChange={event => this.setState({password: event.target.value})}
      required="required"/>
    <input type="password" placeholder="Confirm Password..."
     required="required"/>
    <button className="button_1 authstyle" type="button"
     onClick={() => this.signUp()}>
      Register
    </button>
    <div>
      <Link to={'/signin'} className="linkauth">
        <label className="lblSwFrm">Already Member? Sign In Now.</label>
      </Link>
    </div>
  </form>
  <div>{this.state.error.message}</div>
</div>
</aside>
    )
  }
}

export default SignUp;
