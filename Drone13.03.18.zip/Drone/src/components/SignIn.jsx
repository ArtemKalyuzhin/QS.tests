import React, { Component } from 'react';
import { Link } from 'react-router';
import { firebaseApp } from '../firebase';

class SignIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      error: {
        message: ''
      }
    }
  }

  signIn() {
    console.log('this.state', this.state);
    const { email, password } = this.state;
    firebaseApp.auth().signInWithEmailAndPassword(email, password)
      .catch(error => {
        this.setState({error});
      })
  }

  render() {
    return (
<aside className="form1">
 <div className="dark">
    <h3>Authorization</h3>
      <form className="login-form logform quote" method="post">
        <input className="form-control" type="text" placeholder="Email..."
         onChange={event => this.setState({email: event.target.value})}
           required/>
        <input className="form-control" type="password" placeholder="Password..."
         onChange={event => this.setState({password: event.target.value})}
          required/>
        <button className="button_1 authstyle" type="button"
         onClick={() => this.signIn()}>
          Sign In
        </button>
        <Link  to={'/signup'} className="linkauth">
          <label className="lblSwFrm">Register</label>
        </Link>
      </form>
      <div>{this.state.error.message}</div>
</div>
</aside>    )
  }
}

export default SignIn;
