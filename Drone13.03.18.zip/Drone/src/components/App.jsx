import React, { Component } from 'react';
import { connect } from 'react-redux';
import { firebaseApp } from '../firebase';

class App extends Component {
signOut() {
  // Set hidden style for Menu.
  document.querySelector('.menu_vsblty').style.visibility = "hidden";
  document.querySelector('.sidenav').style.width = "0";
  document.querySelector('.wrapper').style.marginLeft = "0";
  //Sign out
  firebaseApp.auth().signOut();
}

render() {
    return (
      <aside className="form1">
       <div className="dark">
        <div id="user_div">
          <h3>Welcome!</h3>
          <p id="user_signed">User</p>
          <button className="button_1 authstyle" onClick={() => this.signOut()}>
            Logout
          </button>
        </div>
       </div>
     </aside>
    )
  }
}

function mapStateToProps(state) {
  console.log('state', state);
  return {}
}

export default connect(mapStateToProps, null)(App);
