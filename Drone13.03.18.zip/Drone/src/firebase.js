import * as firebase from 'firebase';

//Init
const config = {
  apiKey: "AIzaSyA1MU08DE4k8h4lqFv6XfKiVDgRrlx8Enk",
  authDomain: "akalyuzhin-app.firebaseapp.com",
  databaseURL: "https://akalyuzhin-app.firebaseio.com",
  projectId: "akalyuzhin-app",
  storageBucket: "akalyuzhin-app.appspot.com",
  messagingSenderId: "339214807448"
};

export const firebaseApp = firebase.initializeApp(config);
