// It is a handler of NavBar:
document.querySelector('.sidebar').onclick = function openNav() {
  document.querySelector('.sidenav').style.width = "150px";
  document.querySelector('.wrapper').style.marginLeft = "150px";
}

document.querySelector('.closeBtnNav').onclick = function closeNav() {
  document.querySelector('.sidenav').style.width = "0";
  document.querySelector('.wrapper').style.marginLeft = "0";
}

// To chage font-size:
var btnChangeFontSize = document.querySelector('#changeTagP');
btnChangeFontSize.addEventListener('click', function() {
  document.getElementById("inputPx").focus();
  var p = document.getElementsByTagName("P");
  var inputPxVal = document.getElementById("inputPx").value;
  if (inputPxVal == parseInt(inputPxVal, 10)) {
    if (inputPxVal != '' && inputPxVal >= 8 && inputPxVal <= 24) {
      for (var i = 0; i < p.length; i++) {
        p[i].setAttribute("style", "font-size: " + inputPxVal + "px;");
      }
    } else {
      alert('Select value between 8 and 24 px!');
    }
  } else {
    alert('Data is not an integer!');
  }
  document.getElementById("inputPx").focus();
});


// ----Handler of color picker:
var myColorPicker;
window.addEventListener("load", startup, false);

function startup() {
  myColorPicker = document.getElementById("myColorPicker");
  myColorPicker.addEventListener("input", updateColor, false);
}

function updateColor(event) {
  var selExp = document.getElementById("exprmnt");
  if (selExp) {
    selExp.style.background = event.target.value;
  }
}


// ----Handler of radio buttons:
document.getElementById('changeFontBtn').onclick = function changeFontBtn() {
  var radioBtn = document.getElementsByName("radioFont");
  for (var i = 0; i < radioBtn.length; i++) {
    if (radioBtn[i].checked) {
      var p = document.getElementsByTagName("P");
      for (var j = 0; j < p.length; j++) {
        p[j].setAttribute("style", "font-family: '" + radioBtn[i].value + "', sans-serif;");
      }
      break;
    }
  }
}

// ----handler of Delete button:
document.getElementById('delPBtn').onclick = function deleteLastP() {
  var tagP = document.getElementsByTagName("P");
  var i = tagP.length - 1;
  if (i != null) {
    tagP[i].parentNode.removeChild(tagP[i]);
  }
}


// ----To scroll to top:
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
  scrollFunction()
};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("topBtn").style.display = "block";
  } else {
    document.getElementById("topBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
document.getElementById('topBtn').onclick = function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
