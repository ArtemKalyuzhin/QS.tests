export const SIGNED_IN = 'SIGNED_IN';
