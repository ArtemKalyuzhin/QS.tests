// It is a handler of NavBar: 
var i = 1;

function burgerHandler() {
    if (i == 1) {
        openNav();
        i = 0;
    } else if (i == 0) {
        closeNav();
        i = 1;
    }
}

function openNav() {
    document.getElementById("mySidenav").style.width = "170px";
    document.getElementById("wrapper").style.marginLeft = "170px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("wrapper").style.marginLeft = "0";
}

// To chage font-size:
function changeTagP() {
    document.getElementById("inputPx").focus();
    var p = document.getElementsByTagName("P");
    var inputPxVal = document.getElementById("inputPx").value;
    if (inputPxVal == parseInt(inputPxVal, 10)) {
        if (inputPxVal != '' && inputPxVal >= 8 && inputPxVal <= 24) {
            for (var i = 0; i < p.length; i++) {
                p[i].setAttribute("style", "font-size: " + inputPxVal + "px;");
            }
        } else {
            alert('Select value between 8 and 24 px!');
        }
    } else {
        alert('Data is not an integer!');
    }
    document.getElementById("inputPx").value = '';
}


// ----Handler of color picker:
var myColorPicker;
window.addEventListener("load", startup, false);

function startup() {
    myColorPicker = document.getElementById("myColorPicker");
    myColorPicker.addEventListener("input", updateColor, false);
}

function updateColor(event) {
    var selExp = document.getElementById("exprmnt");
    if (selExp) {
        selExp.style.background = event.target.value;
    }
}


// ----Handler of radios:
function changeFontBtn() {
    var radioBtn = document.getElementsByName("radioFont");
    for (var i = 0; i < radioBtn.length; i++) {
        if (radioBtn[i].checked) {
            document.getElementById("changeFontP").style.fontFamily = radioBtn[i].value;
        }
    }
}

// ----handler of Delete button:
function deleteLastP() {
	var tagP = document.getElementsByTagName("P");
	var i = tagP.length - 1;
	if (i != null){
		tagP[i].parentNode.removeChild(tagP[i]);
	}
}

// ----To scroll to top:
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() { scrollFunction() };

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("topBtn").style.display = "block";
    } else {
        document.getElementById("topBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}