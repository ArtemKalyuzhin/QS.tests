$('#search').keyup(function() {
    var searchField = $('#search').val();
    var myExp = new RegExp(searchField, "i");
    var apiURL = "https://itunes.apple.com/search?term=" + searchField + "&media=music&callback=?";

    var mybutton = document.getElementById('loadbutton');
    mybutton.onclick = function() {
        // 	var apiURL = "https://itunes.apple.com/search?term=" + searchField + "&media=music&callback=?";

        // var apiURL = "https://itunes.apple.com/search?term=The+Beatles&media=music&callback=?";
        $.getJSON(apiURL, function(data) {
            console.log(data);

            var output = '<ul>';
            var resultCount = data.resultCount; // Grab the result count

            for (var i = 0; i < resultCount; i++) {
                output += '<li>';
                output += '<h2>' + data.results[i].artistName + '</h2>';
                output += '<img src="' + data.results[i].artworkUrl100 +
                    '" alt="' +
                    data.results[i].artistName + '" />';
                output += '<p>' + data.results[i].trackName + '</p>';
				output += '<p>' + data.results[i].collectionName + '</p>';
                output += '<p>' + data.results[i].trackName + '</p>';
                output += '<p>' + data.results[i].primaryGenreName + '</p>';
                output += '</li>';
            }

            output += '</ul>';
            $('#update').html(output);
            $( "li:odd" ).css( "background-color", "#ccdff0" );
        });
    }


});

